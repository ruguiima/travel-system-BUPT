package Service;
import mapper.MyBatisUtil;
import mapper.SiteMapper;
import pojo.*;
import org.apache.ibatis.session.SqlSession;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DataGet{

    public void readFromFileAndInsertToDatabase(String filePath) {
        SqlSession session = MyBatisUtil.getSqlSession();
        SiteMapper siteMapper = session.getMapper(SiteMapper.class); // 获取 SiteMapper

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(" "); // 按逗号分隔，假设文件数据格式为 "name,heat,rating"
                Location location = new Location();
                String[] split = line.split(" ");
                location.setId(Integer.parseInt(split[0].substring(1)));
                location.setName(split[1]);
                location.setPopularity(Integer.parseInt(split[2]));
                location.setType(Integer.parseInt(split[3]));
                location.setScore(Float.parseFloat(split[4]));
                location.setScore_number(100);
                siteMapper.site_data_insert(location); // 插入数据库
            }

            session.commit(); // 提交事务
            System.out.println("数据插入成功！");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("数据格式错误，请检查输入的文件数据。");
        } finally {
            session.close(); // 关闭 SqlSession
        }
    }

    public void readFromFileAndInsertToDatabase1(String filePath) {
        SqlSession session = MyBatisUtil.getSqlSession();
        SiteMapper siteMapper = session.getMapper(SiteMapper.class); // 获取 SiteMapper
        String line = new String();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            while ((line = br.readLine()) != null) {
                Diary diary = new Diary();
                diary.setTitle(line);
                line = br.readLine();
                String[] split = line.split(" ");
                diary.setContext(split[0]);
                diary.setScore(Float.parseFloat(split[1]));
                diary.setPopularity(Integer.parseInt(split[2]));
                siteMapper.diary_data_insert(diary); // 插入数据库
            }

            session.commit(); // 提交事务
            System.out.println("数据插入成功！");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.out.println(line);
            System.err.println("数据格式错误，请检查输入的文件数据。");
        } finally {
            session.close(); // 关闭 SqlSession
        }
    }
}
