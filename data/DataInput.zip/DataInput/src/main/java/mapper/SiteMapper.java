package mapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import pojo.Diary;
import pojo.Location;
@Mapper
public interface SiteMapper {
    void site_data_insert(Location location);
    void diary_data_insert(Diary diary);
}
