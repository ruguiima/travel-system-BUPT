package pojo;

public class Location {
    private int id;
    private String name = new String();
    private int type;
    private int popularity;
    private float score;
    private int score_number;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public int getScore_number() {
        return score_number;
    }

    public void setScore_number(int score_number) {
        this.score_number = score_number;
    }
}
