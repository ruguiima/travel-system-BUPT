package pojo;

public class Diary {
    private int id;
    private String title = new String();
    private String context = new String();
    private int author = 0;
    private int popularity;
    private float score;
    private int score_number = 200;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public int getAuthor() {
        return author;
    }

    public void setAuthor(int author) {
        this.author = author;
    }

    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public int getScore_number() {
        return score_number;
    }

    public void setScore_number(int score_number) {
        this.score_number = score_number;
    }
}
