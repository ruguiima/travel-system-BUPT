import Service.DataGet;

public class Main {
    public static void main(String[] args) {
        DataGet loader = new DataGet();
//        loader.readFromFileAndInsertToDatabase("/home/tokistam/IdeaProjects/DataInput/src/main/resources/modified_data.txt");
        loader.readFromFileAndInsertToDatabase1("/home/tokistam/IdeaProjects/DataInput/src/main/resources/cleaned_comments_output.txt");
    }
}
